//
// Created by Nyein on 3/18/2024.
//
#ifndef DSALGOS_H
#define DSALGOS_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// Singly Linked List Node
typedef struct ListNode {
    int data;
    struct ListNode* next;
} ListNode;

// Doubly Linked List Node
typedef struct DListNode {
    int data;
    struct DListNode* prev;
    struct DListNode* next;
} DListNode;

// Stack Node (Using Linked List)
typedef struct StackNode {
    int data;
    struct StackNode* next;
} StackNode;

// Singly Linked List Functions
static inline void insertAtBeginning(ListNode** head, int data) {
    ListNode* newNode = (ListNode*)malloc(sizeof(ListNode));
    newNode->data = data;
    newNode->next = *head;
    *head = newNode;
}

static inline void deleteFromBeginning(ListNode** head) {
    if (*head == NULL) return;
    ListNode* temp = *head;
    *head = (*head)->next;
    free(temp);
}

static inline void displayList(const ListNode* node) {
    while (node != NULL) {
        printf("%d -> ", node->data);
        node = node->next;
    }
    printf("NULL\n");
}

// Doubly Linked List Functions
static inline void insertAtBeginningDList(DListNode** head, int data) {
    DListNode* newNode = (DListNode*)malloc(sizeof(DListNode));
    newNode->data = data;
    newNode->prev = NULL;
    newNode->next = *head;
    if (*head != NULL) (*head)->prev = newNode;
    *head = newNode;
}

static inline void deleteFromBeginningDList(DListNode** head) {
    if (*head == NULL) return;
    DListNode* temp = *head;
    *head = (*head)->next;
    if (*head != NULL) (*head)->prev = NULL;
    free(temp);
}

static inline void displayDList(const DListNode* head) {
    while (head != NULL) {
        printf("%d <-> ", head->data);
        head = head->next;
    }
    printf("NULL\n");
}

// Stack Functions
static inline void push(StackNode** top, int data) {
    StackNode* newNode = (StackNode*)malloc(sizeof(StackNode));
    if (newNode == NULL) {
        printf("Heap Overflow\n");
        return;
    }
    newNode->data = data;
    newNode->next = *top;
    *top = newNode;
}

static inline int pop(StackNode** top) {
    if (*top == NULL) {
        printf("Stack Underflow\n");
        return INT_MIN;
    }
    StackNode* temp = *top;
    int popped = temp->data;
    *top = (*top)->next;
    free(temp);
    return popped;
}

static inline bool isStackEmpty(StackNode* top) {
    return top == NULL;
}

static inline void displayStack(StackNode* top) {
    while (top != NULL) {
        printf("%d -> ", top->data);
        top = top->next;
    }
    printf("NULL\n");
}

#endif // DSALGOS_H
