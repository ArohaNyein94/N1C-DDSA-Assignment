//
// Created by Nyein on 3/18/2024.
//

#include "dsalgos.h"

int main() {
    ListNode* list = NULL;
    DListNode* dlist = NULL;
    StackNode* stack = NULL;

    // Singly Linked List operations
    insertAtBeginning(&list, 10);
    insertAtBeginning(&list, 20);
    displayList(list);
    deleteFromBeginning(&list);
    displayList(list);

    // Doubly Linked List operations
    insertAtBeginningDList(&dlist, 30);
    insertAtBeginningDList(&dlist, 40);
    displayDList(dlist);
    deleteFromBeginningDList(&dlist);
    displayDList(dlist);

    // Stack operations
    push(&stack, 50);
    push(&stack, 60);
    displayStack(stack);
    printf("Popped: %d\n", pop(&stack));
    displayStack(stack);

    return 0;
}
