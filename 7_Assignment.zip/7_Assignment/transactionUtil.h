//
// Created by Nyein on 2/19/2024.
//

#ifndef DDSA_ASSIGNMENT_TRANSATIONUTIL_H
#define DDSA_ASSIGNMENT_TRANSATIONUTIL_H
#include "stdio.h"
#include "n1c.h"
#include "validationUtil.h"
void transaction(int sender_id , int receiver_id,double amount){
    if (!accountStatusCheck(sender_id) || !accountStatusCheck(receiver_id)) {
        return; // Stop the transaction if either account is not active
    }
    // Rest of the transaction code...
    data[sender_id].amount = data[sender_id].amount-amount;
    data[receiver_id].amount = data[receiver_id].amount+amount;
    printf("Transaction Complete From %s to %s : amount=%lf\n",data[sender_id].user_name,data[receiver_id].user_name,amount);
    transaction_record(sender_id , receiver_id,amount);
    all_data();
    my_privilege(sender_id);

}

void transaction_record(int sender_id , int receiver_id,double amount){
    int sender_index= data[sender_id].trans_counter;
    int receiver_index=data[receiver_id].trans_counter;
    char *from="From-";
    char *sender = data[sender_id].user_name;
    char *to="-To-";
    char *receiver= data[receiver_id].user_name;
    char *receive="ReceiveFrom-";
    sprintf((char *) data[sender_id].trans[sender_index].trans_record, "%s%s%s%s%c%lf", from, sender, to, receiver,'-',amount);
    sprintf((char *) data[receiver_id].trans[receiver_index].trans_record, "%s%s%c%lf", receive, sender,'-',amount);

    data[sender_id].trans_counter++;
    data[receiver_id].trans_counter++;

}

void to_transfer_checking(int id){
    double amount=0;
    int receiver_phone=0;//
    int phone_id=0;
    int option=0;
    int cout_wrong=0;
    if (!accountStatusCheck(id)) {
        return; // Stop if the account is not active
    }
    // Rest of the function code...
    printf("Enter your amount to transfer:");
    scanf("%lf",&amount);

    while(data[id].amount>amount+100){
        printf("Enter receiver phone number to send money:");
        scanf("%d",&receiver_phone);
        phone_id =to_check_phone(receiver_phone);
        if(phone_id!=-1){
            transaction(id,phone_id,amount);
        } else{
            printf("This phone number is not available in our system!\n");
            cout_wrong++;
            if(cout_wrong>2){
                fprintf(stderr,"Wrong Phone Number!");
                my_privilege(id);
            }
        }
    }

    printf("Insufficient Amount: %lf\n",data[id].amount);
    printf("Press 1 to continue transaction:\nPress 2 To get Privilege:\n");
    scanf("%d",&option);
    if(option==1){
        to_transfer_checking(id);
    } else if(option==2){
        my_privilege(id);
    } else{
        fprintf(stderr,"Invalid Option\n");
        menu();
    }

}
#endif //DDSA_ASSIGNMENT_TRANSATIONUTIL_H
