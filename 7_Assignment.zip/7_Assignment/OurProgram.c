//
// Created by National Cyber City on 12/18/2023.
//
#include "n1c.h"
#include "transactionUtil.h"
#include "validationUtil.h"
#include "stdio.h"

int main(){
     loading_data_from_file();
     all_data();
     menu();
    return 0;
}