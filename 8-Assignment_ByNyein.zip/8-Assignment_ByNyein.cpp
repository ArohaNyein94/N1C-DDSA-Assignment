//
// Created by Nyein on 2/26/2024.
//
#include <stdio.h>
#include <stdlib.h>

// Define the structure for each node in the doubly linked list
typedef struct Node {
    int data;
    struct Node* next;
    struct Node* prev;
} Node;

// Function to create a new node
Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (!newNode) {
        printf("Memory error\n");
        return NULL;
    }
    newNode->data = data;
    newNode->next = NULL;
    newNode->prev = NULL;
    return newNode;
}

// Function to add a node at the end of the list
void appendNode(Node** head, int data) {
    Node* newNode = createNode(data);
    Node* last = *head;

    // If the list is empty, make the new node as head
    if (*head == NULL) {
        *head = newNode;
        return;
    }

    // Otherwise, traverse till the last node
    while (last->next != NULL) {
        last = last->next;
    }

    // Change the next of last node
    last->next = newNode;
    // Link the previous of new node to the last node
    newNode->prev = last;
}

// Function to delete a node from the list
void deleteNode(Node** head, int key) {
    Node* temp = *head;
    Node* prev = NULL;

    // If the list is empty
    if (temp == NULL) {
        printf("The list is empty\n");
        return;
    }

    // If the head node itself holds the key to be deleted
    if (temp != NULL && temp->data == key) {
        *head = temp->next; // Changed head
        if (*head != NULL) {
            (*head)->prev = NULL;
        }
        free(temp); // free old head
        return;
    }

    // Search for the key to be deleted
    while (temp != NULL && temp->data != key) {
        prev = temp;
        temp = temp->next;
    }

    // If key was not present in linked list
    if (temp == NULL) return;

    // Unlink the node from linked list
    if (temp->next != NULL) {
        temp->next->prev = temp->prev;
    }

    if (temp->prev != NULL) {
        temp->prev->next = temp->next;
    }

    free(temp); // Free memory
}

// Function to print nodes in a given linked list in forward direction
void displayForward(Node* node) {
    while (node != NULL) {
        printf("%d ", node->data);
        node = node->next;
    }
    printf("\n");
}

// Function to print nodes in a given linked list in backward direction
void displayBackward(Node* node) {
    Node* last;
    printf("Traversal in reverse direction: ");
    while (node != NULL) {
        last = node;
        node = node->next;
    }

    // Traversing backward
    while (last != NULL) {
        printf("%d ", last->data);
        last = last->prev;
    }
    printf("\n");
}

int main() {
    Node* head = NULL;

    // Adding nodes to the list
    appendNode(&head, 1);
    appendNode(&head, 2);
    appendNode(&head, 3);
    appendNode(&head, 4);
    appendNode(&head, 5);

    // Display the original list
    printf("Original list: ");
    displayForward(head);

    // Delete a node with value 3 and display the list after deletion
    deleteNode(&head, 3);
    printf("After deleting 3: ");
    displayForward(head);

    // Delete a node with value 1 (head node) and display the list
    deleteNode(&head, 1);
    printf("After deleting 1: ");
    displayForward(head);

    // Delete a node with value 5 (last node) and display the list
    deleteNode(&head, 5);
    printf("After deleting 5: ");
    displayForward(head);

    // Attempt to delete a node with a value not in the list
    deleteNode(&head, 10);
    printf("After attempting to delete a non-existing node (10): ");
    displayForward(head);

    // Displaying list backward to verify backward links are also intact
    printf("Displaying list backward after deletions: ");
    displayBackward(head);

    return 0;
}
