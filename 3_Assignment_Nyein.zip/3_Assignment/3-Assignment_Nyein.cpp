//
// Created by Nyein on 1/1/2024.
//
#include <stdio.h>

// Maximum length for username and password
#define MAX_LENGTH 20
#define MAX_USERS 100

// Structure to store user information
struct User {
    char username[MAX_LENGTH];
    char password[MAX_LENGTH];
    int isLoggedIn;
};

// Function to compare two strings manually
int compareStrings(const char *str1, const char *str2) {
    while (*str1 != '\0' && *str2 != '\0') {
        if (*str1 != *str2) {
            return 0; // Not equal
        }
        str1++;
        str2++;
    }

    // Check if both strings have reached the end simultaneously
    return (*str1 == '\0' && *str2 == '\0');
}

// Function to register a new user
void registerUser(struct User users[], int *userCount) {
    if (*userCount < MAX_USERS) {
        printf("Enter username: ");
        scanf("%s", users[*userCount].username);

        printf("Enter password: ");
        scanf("%s", users[*userCount].password);

        // New user is initially not logged in
        users[*userCount].isLoggedIn = 0;

        (*userCount)++;
        printf("Registration successful!\n");
    } else {
        printf("Maximum number of users reached.\n");
    }
}

// Function to login
void login(struct User users[], int userCount) {
    char username[MAX_LENGTH];
    char password[MAX_LENGTH];

    printf("Enter username: ");
    scanf("%s", username);

    printf("Enter password: ");
    scanf("%s", password);

    for (int i = 0; i < userCount; i++) {
        if (compareStrings(username, users[i].username) && compareStrings(password, users[i].password)) {
            users[i].isLoggedIn = 1;
            printf("Login successful!\n");
            return;
        }
    }

    printf("Invalid username or password. Login failed.\n");
}

// Function to logout
void logout(struct User users[], int userCount) {
    char username[MAX_LENGTH];

    printf("Enter username to logout: ");
    scanf("%s", username);

    for (int i = 0; i < userCount; i++) {
        if (compareStrings(username, users[i].username)) {
            users[i].isLoggedIn = 0;
            printf("Logout successful!\n");
            return;
        }
    }

    printf("User not found. Logout failed.\n");
}

int main() {
    struct User users[MAX_USERS];
    int userCount = 0;
    int choice;

    do {
        printf("\n1. Register\n2. Login\n3. Logout\n4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                registerUser(users, &userCount);
                break;
            case 2:
                login(users, userCount);
                break;
            case 3:
                logout(users, userCount);
                break;
            case 4:
                printf("Exiting program.\n");
                break;
            default:
                printf("Invalid choice. Try again.\n");
        }
    } while (choice != 4);

    return 0;
}
